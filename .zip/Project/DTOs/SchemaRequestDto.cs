﻿namespace Project.DTOs
{
    public class SchemaRequestDto
    {
        public string Name { get; set; }
    }
}
