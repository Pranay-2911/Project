﻿namespace Project.DTOs
{
    public class ForgetPasswordRequestDto
    {
        public string UserName {  get; set; }
    }
}
