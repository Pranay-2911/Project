﻿namespace Project.DTOs
{
    public class QueryResponseDto
    {
        public string Reply { get; set; }
    }
}
