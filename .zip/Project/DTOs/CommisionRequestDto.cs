﻿namespace Project.DTOs
{
    public class CommisionRequestDto
    {
        public double Amount { get; set; }
        public Guid AgentId { get; set; }
    }
}
