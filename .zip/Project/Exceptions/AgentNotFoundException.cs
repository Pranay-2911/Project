﻿namespace Project.Exceptions
{
    public class AgentNotFoundException : Exception
    {
        public AgentNotFoundException(string message) : base(message)
        {
            
        }
    }

}
