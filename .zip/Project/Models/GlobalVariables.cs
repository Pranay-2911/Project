﻿namespace Project.Models
{
    public class GlobalVariables
    {
        public Guid Id { get; set; }
        public float CommissionWithdrawDeduction { get; set; }
        public float PolicyCancellationPenalty { get; set; }
    }
}
