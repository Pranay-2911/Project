﻿namespace Project.Types
{
    public enum NomineeRelation
    {
        FATHER,
        MOTHER,
        BROTHER,
        SISTER
    }
}
