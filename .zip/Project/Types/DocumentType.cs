namespace Project.Types
{
    public enum DocumentType
    {
        AdharCard,
        PanCard,
        VoterId,
        Passport,
        DrivingLicense,
        BankPassbook
    }
}