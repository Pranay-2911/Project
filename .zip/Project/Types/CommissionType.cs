﻿namespace Project.Types
{
    public enum CommissionType
    {
        REGISTRATION,
        PREMIUM
    }
}
