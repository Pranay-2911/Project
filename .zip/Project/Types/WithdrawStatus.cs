﻿namespace Project.Types
{
    public enum WithdrawStatus
    {
        PENDING,
        APPROVED,
        REJECTED
    }
}
