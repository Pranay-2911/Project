﻿namespace Project.Types
{
    public enum Roles
    {

        ADMIN,
        EMPLOYEE,
        AGENT,
        CUSTOMER
    }
}
